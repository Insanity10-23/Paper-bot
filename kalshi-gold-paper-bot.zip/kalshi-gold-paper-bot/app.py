import os
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path

import requests
import streamlit as st
from streamlit_autorefresh import st_autorefresh

APP_DIR = Path(__file__).parent
DB_PATH = Path(os.getenv("DATABASE_PATH", str(APP_DIR / "bot_memory.sqlite3")))
BASE_URL = os.getenv("KALSHI_BASE_URL", "https://external-api.kalshi.com/trade-api/v2")
SERIES = os.getenv("KALSHI_SERIES", "KXGOLD15M")
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "15"))
STARTING_CASH = float(os.getenv("STARTING_CASH", "10000"))
MAX_POSITION_COST = float(os.getenv("MAX_POSITION_COST", "50"))
MAX_OPEN_POSITIONS = int(os.getenv("MAX_OPEN_POSITIONS", "3"))
MIN_PRICE = 0.15
MAX_PRICE = 0.85


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def db():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY, value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL, ticker TEXT, title TEXT,
            status TEXT, yes_bid REAL, yes_ask REAL, last_price REAL,
            close_time TEXT, raw_json TEXT
        );
        CREATE TABLE IF NOT EXISTS decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL, ticker TEXT, action TEXT, reason TEXT,
            yes_price REAL, score REAL, strategy_version INTEGER
        );
        CREATE TABLE IF NOT EXISTS positions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT NOT NULL, title TEXT, side TEXT NOT NULL,
            contracts INTEGER NOT NULL, entry_price REAL NOT NULL,
            cost REAL NOT NULL, opened_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'OPEN',
            settled_at TEXT, result TEXT, pnl REAL
        );
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL,
            note TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS strategy (
            id INTEGER PRIMARY KEY CHECK(id=1),
            version INTEGER NOT NULL DEFAULT 1,
            min_momentum REAL NOT NULL DEFAULT 0.025,
            trades_seen INTEGER NOT NULL DEFAULT 0,
            last_adjustment TEXT
        );
        INSERT OR IGNORE INTO strategy(id, version, min_momentum, trades_seen)
        VALUES(1, 1, 0.025, 0);
        """)
        con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('cash',?)",
                    (str(STARTING_CASH),))
        con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('auto_trade','0')")
        con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('last_prices','{}')")


def get_setting(key, default=None):
    with db() as con:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default


def set_setting(key, value):
    with db() as con:
        con.execute("INSERT INTO settings(key,value) VALUES(?,?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, str(value)))


def api_get(path, params=None):
    response = requests.get(f"{BASE_URL}{path}", params=params, timeout=10,
                            headers={"User-Agent": "kalshi-gold-paper-bot/1.0"})
    response.raise_for_status()
    return response.json()


def as_float(value):
    try:
        return float(value) if value not in (None, "") else None
    except (ValueError, TypeError):
        return None


def market_price(market, *keys):
    for key in keys:
        value = as_float(market.get(key))
        if value is not None:
            return value
    return None


def fetch_markets():
    payload = api_get("/markets", {"series_ticker": SERIES, "status": "open", "limit": 100})
    return payload.get("markets", [])


def record_observations(markets):
    with db() as con:
        for m in markets:
            con.execute("""INSERT INTO observations
                (ts,ticker,title,status,yes_bid,yes_ask,last_price,close_time,raw_json)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (now_iso(), m.get("ticker"), m.get("title"), m.get("status"),
                 market_price(m, "yes_bid_dollars", "yes_bid"),
                 market_price(m, "yes_ask_dollars", "yes_ask"),
                 market_price(m, "last_price_dollars", "last_price"),
                 m.get("close_time"), str(m)[:4000]))


def record_decision(ticker, action, reason, price=None, score=None):
    with db() as con:
        version = con.execute("SELECT version FROM strategy WHERE id=1").fetchone()["version"]
        con.execute("""INSERT INTO decisions(ts,ticker,action,reason,yes_price,score,strategy_version)
                       VALUES(?,?,?,?,?,?,?)""",
                    (now_iso(), ticker, action, reason, price, score, version))


def portfolio():
    with db() as con:
        cash = float(con.execute("SELECT value FROM settings WHERE key='cash'").fetchone()["value"])
        open_positions = con.execute("SELECT * FROM positions WHERE status='OPEN' ORDER BY id DESC").fetchall()
        settled = con.execute("SELECT * FROM positions WHERE status='SETTLED' ORDER BY id DESC").fetchall()
        pnl = sum(float(p["pnl"] or 0) for p in settled)
        wins = sum(1 for p in settled if (p["pnl"] or 0) > 0)
        return cash, open_positions, settled, pnl, wins


def paper_buy(market, price, reason, score):
    if price is None or not (MIN_PRICE <= price <= MAX_PRICE):
        record_decision(market.get("ticker"), "SKIP", "Price outside configured safety range", price, score)
        return
    cash, opens, _, _, _ = portfolio()
    if len(opens) >= MAX_OPEN_POSITIONS:
        record_decision(market.get("ticker"), "SKIP", "Open-position limit reached", price, score)
        return
    with db() as con:
        existing = con.execute("SELECT id FROM positions WHERE ticker=? AND status='OPEN'",
                               (market.get("ticker"),)).fetchone()
        if existing:
            record_decision(market.get("ticker"), "SKIP", "Already have a paper position in this market", price, score)
            return
    cost_limit = min(MAX_POSITION_COST, cash)
    contracts = int(cost_limit // price) if price > 0 else 0
    if contracts < 1:
        record_decision(market.get("ticker"), "SKIP", "Insufficient virtual cash", price, score)
        return
    cost = round(contracts * price, 4)
    with db() as con:
        con.execute("INSERT INTO positions(ticker,title,side,contracts,entry_price,cost,opened_at) VALUES(?,?,?,?,?,?,?)",
                    (market.get("ticker"), market.get("title"), "YES", contracts, price, cost, now_iso()))
        con.execute("UPDATE settings SET value=? WHERE key='cash'", (str(round(cash-cost, 4)),))
    record_decision(market.get("ticker"), "PAPER_BUY_YES", reason, price, score)


def settle_positions():
    # Resolve only when Kalshi's public market response explicitly reports a settled market and result.
    with db() as con:
        positions = con.execute("SELECT * FROM positions WHERE status='OPEN'").fetchall()
    if not positions:
        return
    for pos in positions:
        try:
            payload = api_get(f"/markets/{pos['ticker']}")
            market = payload.get("market", {})
            status = (market.get("status") or "").lower()
            result = (market.get("result") or "").lower()
            if status not in ("settled", "finalized") or result not in ("yes", "no"):
                continue
            payout = float(pos["contracts"]) if result == "yes" else 0.0
            pnl = round(payout - float(pos["cost"]), 4)
            with db() as con:
                current_cash = float(con.execute("SELECT value FROM settings WHERE key='cash'").fetchone()["value"])
                con.execute("UPDATE settings SET value=? WHERE key='cash'", (str(round(current_cash+payout, 4)),))
                con.execute("""UPDATE positions SET status='SETTLED',settled_at=?,result=?,pnl=? WHERE id=?""",
                            (now_iso(), result.upper(), pnl, pos["id"]))
                con.execute("UPDATE strategy SET trades_seen=trades_seen+1 WHERE id=1")
            record_decision(pos["ticker"], "SETTLED", f"Market settled {result.upper()}; paper P/L ${pnl:.2f}")
            maybe_learn()
        except requests.RequestException:
            continue


def maybe_learn():
    with db() as con:
        strat = con.execute("SELECT * FROM strategy WHERE id=1").fetchone()
        if strat["trades_seen"] < 10 or strat["trades_seen"] % 10 != 0:
            return
        recent = con.execute("SELECT pnl FROM positions WHERE status='SETTLED' ORDER BY id DESC LIMIT 10").fetchall()
        if len(recent) < 10:
            return
        win_rate = sum(1 for r in recent if (r["pnl"] or 0) > 0) / 10
        # Small, bounded and transparent adjustment; never changes risk limits or executes real orders.
        old = float(strat["min_momentum"])
        new = min(0.08, old + 0.0025) if win_rate < 0.4 else max(0.01, old - 0.0025) if win_rate > 0.6 else old
        if new != old:
            con.execute("UPDATE strategy SET min_momentum=?,version=version+1,last_adjustment=? WHERE id=1",
                        (new, now_iso()))
            con.execute("INSERT INTO notes(ts,note) VALUES(?,?)",
                        (now_iso(), f"Learning adjustment after {strat['trades_seen']} settled trades: recent 10-trade win rate {win_rate:.0%}; min momentum {old:.4f} -> {new:.4f}."))
        else:
            con.execute("INSERT INTO notes(ts,note) VALUES(?,?)",
                        (now_iso(), f"Learning review after {strat['trades_seen']} trades: recent win rate {win_rate:.0%}; no change."))


def run_strategy(markets):
    # Simple educational baseline: compare current YES midpoint to the previous observed midpoint.
    # It is not a prediction guarantee; trades are simulated at the observed ask, not guaranteed fills.
    import json
    try:
        previous = json.loads(get_setting("last_prices", "{}"))
    except Exception:
        previous = {}
    next_prices = dict(previous)
    with db() as con:
        strat = con.execute("SELECT * FROM strategy WHERE id=1").fetchone()
    threshold = float(strat["min_momentum"])
    for m in markets:
        ticker = m.get("ticker")
        bid = market_price(m, "yes_bid_dollars", "yes_bid")
        ask = market_price(m, "yes_ask_dollars", "yes_ask")
        last = market_price(m, "last_price_dollars", "last_price")
        if not ticker:
            continue
        mid = ((bid + ask) / 2) if bid is not None and ask is not None else last
        if mid is None:
            record_decision(ticker, "SKIP", "No usable YES price in market data")
            continue
        old = previous.get(ticker)
        next_prices[ticker] = mid
        if old is not None and (mid - float(old)) >= threshold and ask is not None:
            if get_setting("auto_trade", "0") == "1":
                paper_buy(m, ask, f"YES midpoint rose {mid-float(old):.3f}, threshold {threshold:.3f}", mid-float(old))
            else:
                record_decision(ticker, "SIGNAL_ONLY", f"Momentum signal; auto paper trading paused (change {mid-float(old):.3f})", ask, mid-float(old))
        else:
            record_decision(ticker, "HOLD", f"No qualifying positive momentum (threshold {threshold:.3f})", ask, (mid-float(old)) if old is not None else None)
    set_setting("last_prices", json.dumps(next_prices))


def money(x):
    return f"${float(x):,.2f}"


st.set_page_config(page_title="Kalshi Gold Paper Bot", page_icon="🪙", layout="wide")
st_autorefresh(interval=max(5, POLL_SECONDS) * 1000, key="market_poll_refresh")
init_db()

st.markdown("""
<style>
.block-container {max-width: 1100px; padding-top: 1.2rem; padding-bottom: 3rem;}
[data-testid="stMetric"] {background: rgba(120,130,150,.08); padding: 12px; border-radius: 12px;}
div.stButton > button {min-height: 44px; border-radius: 10px;}
.small-muted {color: #8b95a5; font-size: .9rem;}
</style>
""", unsafe_allow_html=True)

st.title("🪙 Kalshi Gold · 15m Paper Bot")
st.caption("Live public market data · Simulated portfolio · No real orders")
st.warning("PAPER TRADING ONLY. This app has no order-placement function. Prices can be delayed or unavailable; simulated fills are not guaranteed to match real execution.")

with st.sidebar:
    st.header("Controls")
    auto = st.toggle("Automatic paper trading", value=get_setting("auto_trade", "0") == "1",
                     help="Only creates simulated positions. Never sends Kalshi orders.")
    set_setting("auto_trade", "1" if auto else "0")
    st.caption("Pause any time by switching this off.")
    st.divider()
    st.write("**Safety limits**")
    st.write(f"Max simulated cost per position: {money(MAX_POSITION_COST)}")
    st.write(f"Max open positions: {MAX_OPEN_POSITIONS}")
    st.write(f"Poll interval: {POLL_SECONDS}s")
    st.divider()
    if st.button("Refresh market now", use_container_width=True):
        st.rerun()
    if st.button("Add a note", use_container_width=True):
        st.session_state["show_note"] = not st.session_state.get("show_note", False)
    if st.button("Reset virtual portfolio", type="secondary", use_container_width=True):
        st.session_state["confirm_reset"] = True
    if st.session_state.get("confirm_reset"):
        st.error("This deletes all paper-trading history and resets the fake balance.")
        if st.button("Confirm reset", type="primary"):
            with db() as con:
                for table in ("observations", "decisions", "positions", "notes"):
                    con.execute(f"DELETE FROM {table}")
                con.execute("UPDATE settings SET value=? WHERE key='cash'", (str(STARTING_CASH),))
                con.execute("UPDATE settings SET value='{}' WHERE key='last_prices'")
                con.execute("UPDATE strategy SET version=1,min_momentum=0.025,trades_seen=0,last_adjustment=NULL WHERE id=1")
            st.session_state["confirm_reset"] = False
            st.rerun()

if st.session_state.get("show_note"):
    note = st.text_input("Memory note", placeholder="e.g. Avoid trading when spread is wide")
    if st.button("Save note"):
        if note.strip():
            with db() as con:
                con.execute("INSERT INTO notes(ts,note) VALUES(?,?)", (now_iso(), note.strip()))
            st.success("Note saved.")
            st.session_state["show_note"] = False

markets, fetch_error = [], None
try:
    markets = fetch_markets()
    record_observations(markets)
    settle_positions()
    run_strategy(markets)
except requests.RequestException as exc:
    fetch_error = str(exc)

cash, opens, settled, total_pnl, wins = portfolio()
market_by_ticker = {m.get("ticker"): m for m in markets if m.get("ticker")} if markets else {}
unrealized_pnl = 0.0
for pos in opens:
    market = market_by_ticker.get(pos["ticker"])
    if market:
        bid = market_price(market, "yes_bid_dollars", "yes_bid")
        if bid is not None:
            unrealized_pnl += (bid * int(pos["contracts"])) - float(pos["cost"])
total_pnl_all = total_pnl + unrealized_pnl
total_settled = len(settled)
win_rate = (wins / total_settled * 100) if total_settled else 0
st.subheader("Your portfolio")\nst.caption(f"Total paper P/L: {money(total_pnl_all)} (settled {money(total_pnl)} · estimated open {money(unrealized_pnl)})")
m1, m2, m3, m4 = st.columns(4)
m1.metric("Fake cash available", money(cash))
m2.metric("Settled P/L", money(total_pnl))
m3.metric("Open positions", str(len(opens)))
m4.metric("Win rate", f"{win_rate:.1f}%", help=f"{wins} wins out of {total_settled} settled trades")

if fetch_error:
    st.error(f"Could not refresh Kalshi public market data: {fetch_error}")
    st.info("The dashboard still shows saved paper-trading history. Check your connection and refresh.")
else:
    st.subheader("Live gold markets")
    st.caption(f"Series: {SERIES} · Last checked: {datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')}")
    if not markets:
        st.info("No open market was returned for this series right now. This can happen between windows or when the API is unavailable.")
    else:
        for m in markets:
            bid = market_price(m, "yes_bid_dollars", "yes_bid")
            ask = market_price(m, "yes_ask_dollars", "yes_ask")
            last = market_price(m, "last_price_dollars", "last_price")
            with st.container(border=True):
                st.markdown(f"**{m.get('title') or m.get('ticker', 'Gold market')}**")
                st.caption(f"Ticker: `{m.get('ticker','—')}` · Status: {m.get('status','unknown')} · Closes: {m.get('close_time','unknown')}")
                a, b, c = st.columns(3)
                a.metric("YES bid", f"{bid*100:.1f}¢" if bid is not None else "—")
                b.metric("YES ask", f"{ask*100:.1f}¢" if ask is not None else "—")
                c.metric("Last price", f"{last*100:.1f}¢" if last is not None else "—")
                if st.button("Log manual observation", key=f"obs-{m.get('ticker')}"):
                    record_decision(m.get("ticker"), "MANUAL_NOTE", "User logged a market observation", ask or last)
                    st.toast("Observation logged")

tab1, tab2, tab3 = st.tabs(["Open positions", "Settled trades", "Memory & learning"])
with tab1:
    if opens:
        st.dataframe([dict(p) for p in opens], use_container_width=True, hide_index=True)
    else:
        st.info("No open paper positions.")
with tab2:
    if settled:
        st.dataframe([dict(p) for p in settled], use_container_width=True, hide_index=True)
    else:
        st.info("No settled paper trades yet.")
with tab3:
    with db() as con:
        strat = con.execute("SELECT * FROM strategy WHERE id=1").fetchone()
        decisions = con.execute("SELECT ts,ticker,action,reason,yes_price,score,strategy_version FROM decisions ORDER BY id DESC LIMIT 50").fetchall()
        notes = con.execute("SELECT * FROM notes ORDER BY id DESC LIMIT 50").fetchall()
        observations = con.execute("SELECT ts,ticker,yes_bid,yes_ask,last_price FROM observations ORDER BY id DESC LIMIT 50").fetchall()
    st.markdown("**Strategy parameters**")
    st.write(f"Version: {strat['version']} · Momentum threshold: {strat['min_momentum']:.4f} · Settled trades counted: {strat['trades_seen']}")
    st.caption("Learning rule: review every 10 settled trades. Recent win rate below 40% raises the entry threshold slightly; above 60% lowers it slightly. The threshold is bounded from 0.01 to 0.08. Risk limits are never learned or changed.")
    st.markdown("**Recent decisions**")
    st.dataframe([dict(x) for x in decisions], use_container_width=True, hide_index=True)
    st.markdown("**Market observations**")
    st.dataframe([dict(x) for x in observations], use_container_width=True, hide_index=True)
    st.markdown("**Notes / learning log**")
    st.dataframe([dict(x) for x in notes], use_container_width=True, hide_index=True)

st.divider()
st.caption("Educational software. Paper results are hypothetical and do not predict real outcomes. Market data schema and availability may change.")
time.sleep(0.1)
