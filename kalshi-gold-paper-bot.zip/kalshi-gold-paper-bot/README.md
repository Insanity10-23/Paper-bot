# Kalshi Gold 15m Paper Bot

A mobile-friendly Streamlit dashboard for monitoring Kalshi's 15-minute gold series (`KXGOLD15M`) using public market data. It maintains a **virtual portfolio only**.

## Safety first

- **No real orders are placed.** The project has no order-submission code.
- No Kalshi API key is required for the public market-data endpoints used here.
- All cash and positions are simulated.
- Paper fills use the observed YES ask and are simplified assumptions, not guaranteed execution.
- The strategy is an educational momentum baseline, not a reliable prediction model or financial advice.

## Features

- Public market polling for the gold 15-minute series
- Virtual cash, open positions, settled trades, P/L and win rate
- Automatic paper-trading pause/resume switch
- SQLite memory for observations, decisions, positions, notes and strategy adjustments
- Bounded, logged strategy adjustments after every 10 settled trades
- Phone-friendly Streamlit layout

## Start from an iPhone (no PC required)

The simplest browser-only route is to create the repository on GitHub and deploy it with a hosted Python app service that supports Streamlit. You can do the GitHub steps in Safari or the GitHub app.

1. Sign in at [GitHub](https://github.com/) in Safari.
2. Tap **+** → **New repository**. Name it `kalshi-gold-paper-bot`.
3. Choose **Public** or **Private**, then create it.
4. Add these files from this project to the repository: `app.py`, `requirements.txt`, `.gitignore`, `.env.example`, and this `README.md`. On GitHub's mobile website, use **Add file → Create new file** and paste each file's contents. For `app.py`, the file is long; uploading the ZIP from a browser-based cloud development environment is often easier.
5. Deploy the repository to a Python hosting service that supports Streamlit. Set the entry file to `app.py`.
6. Open the deployed URL on your iPhone. Use Safari's **Share → Add to Home Screen** to make it feel like an app.

### Important hosting/database note

The default SQLite database is stored on the machine running the app. Many free hosting services use temporary storage or sleep when idle, so database history may be lost on rebuild/restart and continuous polling is not guaranteed. For durable always-on use, attach persistent storage or replace SQLite with a managed database. Do not put secrets in source code. This app does not need a Kalshi API secret for public market data.

## Run locally or in a hosted terminal

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

## Configuration

The app reads optional environment variables:

| Variable | Default | Purpose |
|---|---|---|
| `KALSHI_SERIES` | `KXGOLD15M` | Series ticker to monitor |
| `KALSHI_BASE_URL` | `https://external-api.kalshi.com/trade-api/v2` | Public market-data API base |
| `POLL_SECONDS` | `15` | Displayed intended polling interval |
| `STARTING_CASH` | `10000` | Starting fake cash in dollars |
| `MAX_POSITION_COST` | `50` | Max virtual cost per position |
| `MAX_OPEN_POSITIONS` | `3` | Max simultaneous paper positions |
| `DATABASE_PATH` | `bot_memory.sqlite3` | SQLite database file path |

The dashboard refreshes while open at the configured polling interval. It is not a guaranteed background scheduler: the browser tab and hosted app must remain active, and hosting sleep can interrupt polling.

## Strategy overview

- Uses a simple positive change in the YES midpoint versus the prior observed midpoint.
- If automatic paper trading is enabled, it simulates a YES entry at the current observed ask, subject to price, cash, and position limits.
- Settles only when the public market endpoint explicitly reports a settled/finalized status and a YES/NO result.
- Reviews the last 10 settled positions. If the win rate is below 40%, the momentum threshold rises slightly; above 60%, it lowers slightly. Changes are small, bounded, and logged.
- This simple learning rule is not statistically robust. A small number of wins/losses can be noisy.

## Known limitations

- The market data API response format and series availability can change.
- No open market may be returned between windows.
- This first version uses polling rather than a WebSocket.
- The app uses a simplified paper fill model and does not fully model fees, order-book depth, slippage or partial fills.
- Hosted free-tier sleep and ephemeral disk can interrupt polling or erase local SQLite data.
- This is a starter implementation, not a production trading system.
